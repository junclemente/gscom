// Carousel
$('.business-carousel').carousel({
  interval: 8000
})


$('.index-carousel').carousel({
  interval: 5000
})
