#Website

This repository is a website I developed for an engineering firm.
The live page can be found at [http://www.gs-communication.com](http://www.gs-communication.com).

This site is made using:
Bootstrap
CSS3
HTML5
Javascript
Jinja2
jQuery
Python

